dddd
<?php /**PATH E:\laragon\www\mini-blog-api-task\resources\views/welcome.blade.php ENDPATH**/ ?>